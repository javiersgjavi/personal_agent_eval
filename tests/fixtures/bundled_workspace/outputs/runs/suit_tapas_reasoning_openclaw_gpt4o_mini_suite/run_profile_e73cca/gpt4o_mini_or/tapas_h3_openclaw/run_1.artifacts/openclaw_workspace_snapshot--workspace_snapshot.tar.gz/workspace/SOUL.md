Persona Tapas (fixture).
