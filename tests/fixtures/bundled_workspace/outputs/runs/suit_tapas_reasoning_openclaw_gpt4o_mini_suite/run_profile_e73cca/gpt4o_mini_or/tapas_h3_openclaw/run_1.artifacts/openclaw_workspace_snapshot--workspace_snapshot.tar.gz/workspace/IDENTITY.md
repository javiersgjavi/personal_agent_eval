# IDENTITY

Benchmark-generated placeholder for OpenClaw workspace materialization.
This file was missing from the reusable agent workspace template.
